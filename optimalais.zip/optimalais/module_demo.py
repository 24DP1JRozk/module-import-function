import module_using_name

module_using_name.speak()