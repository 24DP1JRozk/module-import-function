def say_hi():
    print('Hi, this is mymodule speaking.')

__version__ = '0.1'