from random import *

saraksts = [1,2,3]

print(randint(1,6))
print(choice(saraksts))