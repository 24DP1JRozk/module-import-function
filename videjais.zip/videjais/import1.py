import random

saraksts = [1,2,3]

print(random.randint(1,6))
print(random.choice(saraksts))